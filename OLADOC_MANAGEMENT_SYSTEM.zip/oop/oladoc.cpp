#include <iostream>
#include <fstream>
#include "string"
#include "user.h"
#include "doctor.h"
#include "patient.h"
#include "admin.h"
#include "appointment.h"

/*
Muhammad Ali Ahson
21i-2535
Sectiom C

*/


using namespace std;
int main() {
	user a;
	a.Menu();


	return 0;
}